//
//  PythagorusViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class PythagorusViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction15(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is BiographyViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction15(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is TheoryScreenViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
