//
//  CubeOctViewController.swift
//  Pocket Pythagoras
//
//  Created by Владислав on 09.02.2022.
//
// FAULT
import UIKit

class CubeOctViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_37(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SpecFigViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_37(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is SpecFigViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
