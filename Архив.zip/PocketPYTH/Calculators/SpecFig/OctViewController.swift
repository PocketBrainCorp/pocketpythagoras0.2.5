//
//  OctViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 20.12.2021.
//

import UIKit

class OctViewController: UIViewController {

    
    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var result: UILabel!

    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        
        if (a > 0 && a < 9223372036854775807){
            let V = ((pow(a, 3)*(sqrt(2)))/3);
            
            if (V - floor(V) == 0){
                result.text = String(Int(V));
            } else {
                result.text = String(V);
            }
        } else {
            result.text = String("Введено некорректное значение!")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_33(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SpecFigViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_33(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is SpecFigViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
