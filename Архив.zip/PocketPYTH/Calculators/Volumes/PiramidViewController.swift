//
//  PiramidViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class PiramidViewController: UIViewController {

    @IBOutlet weak var S: UITextField!
    @IBOutlet weak var h: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let S = Double(S.text!) ?? 0.0
        let h = Double(h.text!) ?? 0.0
        
        if (S > 0 && h > 0 && S < 9223372036854775807 && h < 9223372036854775807){
            let V = (1/3)*S*h
            
            if (V - floor(V) == 0) {
                result.text = String(Int(V))
            } else {
                result.text = String(V)
            }
        } else {
            result.text = String("Введены некорректные данные!")
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_71(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is VolumeViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_71(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is VolumeViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}

