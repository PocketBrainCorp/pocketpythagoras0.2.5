//
//  CylinderViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 04.11.2021.
//

import UIKit

class CylinderViewController: UIViewController {

    @IBOutlet weak var h: UITextField!
    @IBOutlet weak var r: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let h = Double(h.text!) ?? 0.0
        let r = Double(r.text!) ?? 0.0
        
        if (h > 0 && r > 0 && h < 9223372036854775807 && r < 9223372036854775807){
            let V = 3.14*r*r*h
            
            if (V - floor(V) == 0){
                result.text = String(Int(V))
            } else {
                result.text = String(V)
            }
        } else {
            result.text = String("Введены некорректные данные!")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_68(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is VolumeViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_68(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is VolumeViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
