//
//  FourAnglePrismViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 04.11.2021.
//

import UIKit

class FourAnglePrismViewController: UIViewController {
    
    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var h: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let h = Double(h.text!) ?? 0.0
        
        if (a > 0 && b > 0 && h > 0 && a < 9223372036854775807 && b < 9223372036854775807 && h < 9223372036854775807){
            let V = h*a*b
            
            if (V - floor(V) == 0){
                result.text = String(Int(V))
            } else {
                result.text = String(V)
            }
        } else {
            result.text = String("Введены некорректные данные!")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_69(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }
    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is VolumeViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_69(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is VolumeViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}

