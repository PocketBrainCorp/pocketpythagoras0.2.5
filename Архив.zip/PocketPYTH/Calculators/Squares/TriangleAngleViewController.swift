//
//  TriangleAngleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 07.12.2021.
//

import UIKit

class TriangleAngleViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var angle: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let angle = Double(angle.text!) ?? 0.0
        let alpha = sin(angle * M_PI / 180)
        
        if (a > 0 && b > 0 && angle > 0 && a < 9223372036854775807 && b < 9223372036854775807 && angle < 9223372036854775807){
            let S = (1/2)*a*b*alpha
            if (S - floor(S) == 0){
                result.text = String(Int(S))
            } else if S - floor(S) != 0 && ((round(S) - S) <= 0.1){
                result.text = String(round(S))
            } else if S - floor(S) != 0 && ((round(S) - S) >= 0.1){
                result.text = String(S)
            }
        } else {
            result.text = String("Введены некорректные данные!")
        }
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_60(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_60(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is SquareViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
