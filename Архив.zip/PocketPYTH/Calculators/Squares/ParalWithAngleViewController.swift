//
//  ParalWithAngleViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 06.12.2021.
//

import UIKit

class ParalWithAngleViewController: UIViewController {

    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var angle: UITextField!
    @IBOutlet weak var result: UILabel!
    
    
    @IBAction func Res(_ sender: UIButton) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let sinus = Double(angle.text!) ?? 0.0
        let alpha = sin(sinus * M_PI / 180)
        
        if (sinus < 91 && a > 0 && b > 0 && a < 9223372036854775807 && b < 9223372036854775807){
            let S = a*b*alpha
            
            if (S - floor(S) == 0){
                result.text = String(Int(S))
            } else {
                result.text = String(S)
            }
        } else {
            result.text = String("Введены некорректные данные!")
        }
     }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_42(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is SquareViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_42(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is SquareViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
