//
//  PolyhedronViewController.swift
//  Pocket Pythagoras
//
//  Created by Владислав on 12.02.2022.
//

import UIKit

class PolyhedronViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is CalcViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
