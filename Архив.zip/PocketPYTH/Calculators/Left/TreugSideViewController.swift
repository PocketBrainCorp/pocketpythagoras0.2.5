//
//  TreugSideViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 17.01.2022.
//

import UIKit

class TreugSideViewController: UIViewController {


    @IBOutlet weak var a: UITextField!
    @IBOutlet weak var b: UITextField!
    @IBOutlet weak var angle: UITextField!
    @IBOutlet weak var result: UILabel!
    
    @IBAction func Res(_ sender: Any) {
        let a = Double(a.text!) ?? 0.0
        let b = Double(b.text!) ?? 0.0
        let angle = Double(angle.text!) ?? 0.0
        let cosinus = cos(angle * M_PI / 180)
        
        if (a > 0 && b > 0 && angle > 0 && a < 9223372036854775807 && b < 9223372036854775807 && angle < 9223372036854775807){
            let res = sqrt((pow(a,2) + pow(b,2) - 2*a*b*cosinus))
            
            if (angle != 0 && angle < 359){
                if (res - floor(res)) == 0{
                    result.text = String(Int(res))
                } else {
                    result.text = String(res)
                }
            } else {
                result.text = String("Введены некорректные данные!")
            }
        } else {
            result.text = ("Введены некорректные данные!")
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_39(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }

    @IBAction func GoBack(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is LeftViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_39(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is LeftViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
