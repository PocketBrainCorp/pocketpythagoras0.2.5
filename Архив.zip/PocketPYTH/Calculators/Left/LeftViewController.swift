//
//  LeftViewController.swift
//  Pocket Pythagorus
//
//  Created by Владислав on 19.10.2021.
//

import UIKit

class LeftViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(swipeAction_401(swipe:)))
        swipeRight.direction = UISwipeGestureRecognizer.Direction.right
        self.view.addGestureRecognizer(swipeRight)
    }

    @IBAction func goToCalc(_ sender: Any) {
        if let viewControllers = self.navigationController?.viewControllers{
            for vc in viewControllers{
                if vc is CalcViewController{
                    self.navigationController?.popViewController(animated: true)
                }
            }
        }
    }
}
extension UIViewController{
    @objc func swipeAction_401(swipe:UISwipeGestureRecognizer){
        switch swipe.direction.rawValue {
        case 1:
            if let viewControllers = self.navigationController?.viewControllers{
                for vc in viewControllers{
                    if vc is CalcViewController{
                        self.navigationController?.popViewController(animated: true)
                    }
                }
            }
        default:
            break
        }
    }
}
